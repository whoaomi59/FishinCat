from cx_Freeze import setup, Executable

# Listado de archivos .py adicionales que deseas incluir
include_files = [
    ("def/def.py", "def/def.py"),  # Copiar al mismo nivel
    ("dor/dor.py", "dor/dor.py")   # Copiar al mismo nivel
]

setup(
    name="ParaTiHIja",
    version="1.0",
    description="Descripción de mi aplicación",
    options={
        "build_exe": {
            "include_files": include_files
        }
    },
    executables=[Executable("flower.py", base="Win32GUI", icon="ico/flowe.ico")],
)
